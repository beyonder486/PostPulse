function extractMetrics() {
  try {
    const posts = document.querySelectorAll('div.feed-shared-update-v2');
    const data = Array.from(posts).map((post, i) => {
      const content = post.innerText || "";
      const likes = post.querySelector('[aria-label*="like"]')?.textContent?.trim() ?? "0";
      const comments = post.querySelector('[aria-label*="comment"]')?.textContent?.trim() ?? "0";
      const views = post.querySelector('[aria-label*="views"]')?.textContent?.trim() ?? "0";
      // Try to extract posted_at (safe, won't break scraping)
      let relativeTime = null;
      const timeSpans = post.querySelectorAll('span[aria-hidden="true"]');
      for (const span of timeSpans) {
        const txt = span.innerText.trim().split('•')[0].trim();
        if (/^\d+(s|m|h|d|w|mo|y)$/.test(txt)) {
          relativeTime = txt;
          break;
        }
      }
      const posted_at = parseRelativeTime(relativeTime);

      return {
        id: i,
        content,
        likes,
        comments,
        views,
        post_url: window.location.href,
        posted_at
      };
    });

    // 🔐 Get the stored token and send the message
    chrome.runtime.sendMessage({ type: "GET_SUPABASE_TOKEN" }, (response) => {
      const user_token = response?.supabase_token;
      console.log("🔑 Got user_token from storage:", user_token);
      chrome.runtime.sendMessage({
        type: "POST_METRICS",
        data,
        user_token
      });
    });

    console.log("📤 Metrics prepared for sending:", data);
  } catch (err) {
    console.error("❌ Error extracting LinkedIn metrics", err);
  }
}

function parseRelativeTime(str) {
  if (!str) return null;
  const now = new Date();
  const match = str.match(/^(\d+)(s|m|h|d|w|mo|y)$/);
  if (!match) return null;
  const value = parseInt(match[1], 10);
  const unit = match[2];
  switch (unit) {
    case 's': now.setSeconds(now.getSeconds() - value); break;
    case 'm': now.setMinutes(now.getMinutes() - value); break;
    case 'h': now.setHours(now.getHours() - value); break;
    case 'd': now.setDate(now.getDate() - value); break;
    case 'w': now.setDate(now.getDate() - value * 7); break;
    case 'mo': now.setMonth(now.getMonth() - value); break;
    case 'y': now.setFullYear(now.getFullYear() - value); break;
    default: return null;
  }
  return now.toISOString();
}

// Example scraping logic (customize selectors as needed)
function scrapeLinkedInMetrics() {
  return Array.from(document.querySelectorAll('.feed-shared-update-v2')).map(post => {
    const content = post.innerText || ""; 
    const postUrl = post.querySelector('a')?.href || window.location.href;
    const likes = parseInt(post.querySelector('.social-details-social-counts__reactions-count')?.innerText.replace(/[^\d]/g, '') || '0', 10);
    const comments = parseInt(post.querySelector('.social-details-social-counts__comments')?.innerText.replace(/[^\d]/g, '') || '0', 10);

    let relativeTime = null;
    const timeSpans = post.querySelectorAll('span[aria-hidden="true"]');
    for (const span of timeSpans) {
      const txt = span.innerText.trim().split('•')[0].trim();
      if (/^\d+(s|m|h|d|w|mo|y)$/.test(txt)) {
        relativeTime = txt;
        break;
      }
    }
    const posted_at = parseRelativeTime(relativeTime);

    return {
      post_url: postUrl,
      likes,
      comments,
      posted_at,
      content
    };
  });
}

// Listen for messages from the popup or background
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'getMetrics') {
    const metrics = scrapeLinkedInMetrics();
    console.log('Scraped metrics:', metrics);
    sendResponse(metrics);
    return true; // Keep the message channel open for async response
  }
});

// Optional: Automatically send metrics after page load (if needed)
console.log("🔥 LinkedIn content script loaded");
setTimeout(extractMetrics, 3000); // Let LinkedIn fully load before scraping
